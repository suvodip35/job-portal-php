<?php
  echo "<script>window.location.href = '/amp/job'</script>";
?>